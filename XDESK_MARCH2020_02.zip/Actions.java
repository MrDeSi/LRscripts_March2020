import lrapi.lr;
import java.sql.*;
import oracle.jdbc.driver.*;
import java.sql.DriverManager;
import java.sql.Connection;


public class Actions
{

	public int init() throws Throwable {
		return 0;
	}//end of init


	public int action() throws Throwable, SQLException {
		
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

		Connection conn =
		DriverManager.getConnection(
		"jdbc:oracle:thin:@192.168.14.53:1522:orcl","c##x5","c##x5");
		Statement stmt = conn.createStatement();
		PreparedStatement statement = null;

		ResultSet rs =
		stmt.executeQuery("SELECT id FROM TICKET WHERE STATE_ID = '-1' AND ROWNUM=1");

		while(rs.next()){
		int number = rs.getInt("id");
		
		statement = conn.prepareStatement("UPDATE TICKET SET STATE_ID=1 WHERE ID= ?");
        	statement.setInt(1, number);
        	statement.executeUpdate();
        
        	statement = conn.prepareStatement("INSERT INTO TASK (ID, TICKET_ID, STATE_ID, CLIENT_ID, GUID, HEADER, TEXT, CREATE_DATE, EXTERNAL_SYSTEM) SELECT ID, ID,STATE_ID, '106', GUID, HEADER, TEXT, CREATE_DATE, 'ASKO' FROM TICKET WHERE ID= ?");
        	statement.setInt(1, number);
        	statement.executeUpdate();


		}

		rs.close();
		stmt.close();
		conn.close();
		
		
		return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end
}
