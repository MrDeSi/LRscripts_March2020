vuser_end()
{

	web_custom_request("gts1o1_3", 
		"URL=http://ocsp.pki.goog/gts1o1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\xAE\\xBF\\x00Q\\x0C6\\xFA\\xF0\\x08\\x00\\x00\\x00\\x000\\xCE+", 
		LAST);

	web_custom_request("gts1o1_4", 
		"URL=http://ocsp.pki.goog/gts1o1", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\xD5\\x13\\xF6\r\\x08\\xA7\\xF4\\x83\\x08\\x00\\x00\\x00\\x002\\x08\\xB4", 
		LAST);

	lr_start_transaction("UC04_T99_logout");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(17);

	web_url("logout", 
		"URL=http://192.168.14.54:9433/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("sessionExpired=false; DOMAIN=192.168.14.54");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("login_3", 
		"URL=http://192.168.14.54:9433/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC04_T99_logout",LR_AUTO);

	return 0;
}