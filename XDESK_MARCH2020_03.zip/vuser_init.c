/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 971
   ------------------------------------------------------------------------------- */

vuser_init()
{
	web_url("login", 
		"URL=http://192.168.14.54:9433/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	lr_start_transaction("UC03_T00_login");

	web_add_header("Origin", 
		"http://192.168.14.54:9433");

	web_submit_data("login_2", 
		"Action=http://192.168.14.54:9433/api/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value={Login}", ENDITEM, 
		//"Name=login", "Value=engineer", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		"Name=rememberMe", "Value=false", ENDITEM,
		LAST);

	web_add_cookie("currentCompany=0; DOMAIN=192.168.14.54");

	web_add_cookie("currentUser={Login}; DOMAIN=192.168.14.54");
	
	web_add_cookie("currentUser=engineer; DOMAIN=192.168.14.54");

	web_add_cookie("PFLB.pre.login.link=null; DOMAIN=192.168.14.54");

	web_url("192.168.14.54:9433", 
		"URL=http://192.168.14.54:9433/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/login", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("checkLogin", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T00_login",LR_AUTO);

	return 0;
}
