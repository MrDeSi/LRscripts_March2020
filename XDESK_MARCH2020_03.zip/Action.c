Action()
{

	lr_start_transaction("UC03_T01_commentary");

	web_reg_save_param_json ("ParamName=IdIncident",
	"QueryString=$..content[*].id",
	"SelectAll=Yes",
	LAST);
	
	web_custom_request("ticket",
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);
	
	lr_save_string (lr_paramarr_random("IdIncident"), "IdIncidentRandom");
	
	web_custom_request("OurIncident", 
		"URL=http://192.168.14.54:9433/api/ticket/{IdIncidentRandom}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_url("comment", 
		"URL=http://192.168.14.54:9433/api/ticket/{IdIncidentRandom}/comment/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://192.168.14.54:9433");

	web_custom_request("comment_2", 
		"URL=http://192.168.14.54:9433/api/ticket/{IdIncidentRandom}/comment/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"text\":\"THE COMMENT\",\"files\":[]}", 
		LAST);

	web_url("comment_3", 
		"URL=http://192.168.14.54:9433/api/ticket/{IdIncidentRandom}/comment/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC03_T01_commentary",LR_AUTO);

	return 0;
}
