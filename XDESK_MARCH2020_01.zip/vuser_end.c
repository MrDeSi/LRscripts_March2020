vuser_end()
{

	lr_start_transaction("UC01_T99_logout");

	web_url("logout", 
		"URL=http://192.168.14.54:9433/api/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("sessionExpired=false; DOMAIN=192.168.14.54");

	web_url("login_3", 
		"URL=http://192.168.14.54:9433/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T99_logout",LR_AUTO);

	return 0;
}