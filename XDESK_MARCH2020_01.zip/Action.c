Action()
{
	int num;
	int randNum;

	lr_start_transaction("UC01_T01_createincident");

	web_add_cookie("filterSetting="
		"%7B%22page%22%3A%22http%3A%2F%2F192.168.14.54%3A9433%2F%23tickets%3Fstate%3Dopened%26page%3D1%22%2C%22smho%22%3Anull%2C%22dateStart%22%3A%22%22%2C%22dateEnd%22%3A%22%22%2C%22cat1%22%3Anull%2C%22cat2%22%3Anull%2C%22cat3%22%3Anull%2C%22cat4%22%3Anull%2C%22theme%22%3Anull%2C%22engineer%22%3Anull%2C%22location%22%3Anull%2C%22division%22%3Anull%2C%22overdue%22%3Afalse%2C%22filters%22%3A%7B%22newCheckbox%22%3Atrue%2C%22appointedCheckbox%22%3Atrue%2C%22performedCheckbox%22%3Atrue%2C%22controlCheckbox%22%"
		"3Atrue%7D%7D; DOMAIN=192.168.14.54");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");


	web_url("catalog.dust", 
		"URL=http://192.168.14.54:9433/engineer/catalog/catalog.dust", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t30.inf", 
		LAST);

	web_url("catalog.js", 
		"URL=http://192.168.14.54:9433/engineer/catalog/catalog.js", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t31.inf", 
		LAST);

	web_url("children", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/0/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param_json ("ParamName=IdAdr",
	"QueryString=$..id",
	"SelectAll=Yes",
	LAST);
	
	web_url("shops", 
		"URL=http://192.168.14.54:9433/api/shops?q=&page=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_url("children_2", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/0/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_string (lr_paramarr_random("IdAdr"), "IdAdrRandom");
	
	web_reg_save_param_json ("ParamName=IdParent",
	"QueryString=$..parentId",
	"SelectAll=Yes",
	LAST);
	
	web_reg_save_param_json ("ParamName=IdParentName",
	"QueryString=$..parentName",
	"SelectAll=Yes",
	LAST);

	web_url("treeview", 
		"URL=http://192.168.14.54:9433/api/user/catalog/treeview?shopid={IdAdrRandom}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		EXTRARES,
		"Url=/engineer/catalog/catalog.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		"Url=/engineer/catalog/catalog.js", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);
	
	
	randNum = rand() % lr_paramarr_len ("IdParentName");
			
	lr_save_string (lr_eval_string(lr_paramarr_idx("IdParent", randNum)), "IdParentRandom");

	lr_save_string (lr_eval_string(lr_paramarr_idx("IdParentName", randNum)), "IdParentNameRandom");

	web_url("children_3", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/{IdParentRandom}/children/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		LAST);	
	
	web_reg_save_param_json ("ParamName=IdService",
	"QueryString=$..id",
	"SelectAll=Yes",
	LAST);
	
	/*web_reg_save_param_json ("ParamName=IdName",
	"QueryString=$..name",
	"SelectAll=Yes",
	LAST);*/

	web_url("service", 
		"URL=http://192.168.14.54:9433/api/user/catalog/node/{IdParentRandom}/service/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);

	web_url("OurParent", 
		"URL=http://192.168.14.54:9433/api/user/catalog/breadcrumbs/{IdParentRandom}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/engineer/addticket.dust", "Referer=http://192.168.14.54:9433/", ENDITEM, 
		LAST);
	
	lr_save_string (lr_paramarr_random("IdService"), "IdSerRandom");
	
	web_reg_save_param_json ("ParamName=IdInventNum",
	"QueryString=$..id",
	"SelectAll=Yes",
	"Notfound=warning",
	LAST);

	web_url("inventoryNumbers", 
		"URL=http://192.168.14.54:9433/api/inventoryNumbers?serviceId={IdSerRandom}&shopId={IdAdrRandom}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		LAST);

	web_url("inventoryNumbers_2", 
		"URL=http://192.168.14.54:9433/api/inventoryNumbers?shopId={IdAdrRandom}&serviceId={IdSerRandom}&serviceId={IdSerRandom}&q=&page=0", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);
	
//	num = lr_paramarr_len("IdInventNum");
	
//	if(strcmp(lr_eval_string("IdInventNum"),"")!=0){
//		lr_save_string (lr_paramarr_random("IdInventNum"), "IdInventNumRandom");
//	}
	
//	lr_save_int(lr_paramarr_len("IdInventNum"), "IdInventNumLen");
	
	if (lr_paramarr_len("IdInventNum") != 0) {		
		lr_save_string (lr_paramarr_random("IdInventNum"), "IdInventNumRandom");		
	} else {		
		lr_save_string ("null", "IdInventNumRandom");		
	}
	
	

	web_add_header("Origin", 
		"http://192.168.14.54:9433");

	web_custom_request("ticket_2", 
		"URL=http://192.168.14.54:9433/api/ticket/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		//"BodyBinary={\"text\":\"\",\"header\":\"\\xD0\\x9E\\xD1\\x82\\xD1\\x81\\xD1\\x83\\xD1\\x82\\xD1\\x81\\xD1\\x82\\xD0\\xB2\\xD0\\xB8\\xD0\\xB5 \\xD0\\xBC\\xD0\\xBE\\xD1\\x8E\\xD1\\x89\\xD0\\xB8\\xD1\\x85 \\xD1\\x81\\xD1\\x80\\xD0\\xB5\\xD0\\xB4\\xD1\\x81\\xD1\\x82\\xD0\\xB2\",\"ticketStateId\":0,\"serviceId\":\"{IdSerRandom}\",\"files\":[],\"inventoryNumberId\":\"{IdInventNumRandom}\",\"shopId\":\"{IdAdrRandom}\"}", 
		"BodyBinary={\"text\":\"\",\"header\":\"{IdParentNameRandom}\",\"ticketStateId\":0,\"serviceId\":\"{IdSerRandom}\",\"files\":[],\"inventoryNumberId\":\"{IdInventNumRandom}\",\"shopId\":\"{IdAdrRandom}\"}", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("192.168.14.54:9433_2", 
		"URL=http://192.168.14.54:9433/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/js/core/jqueryformplugin.js?_=1583654482773", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.dust", ENDITEM, 
		"Url=/engineer/wrapper/wrapper.js", ENDITEM, 
		"Url=/engineer/tickets/tickets.dust", ENDITEM, 
		"Url=/engineer/tickets/tickets.js", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("checkLogin_2", 
		"URL=http://192.168.14.54:9433/api/checkLogin", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		LAST);

	web_url("info_2", 
		"URL=http://192.168.14.54:9433/api/user/info", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_url("4_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/4", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_2", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	web_url("countByState_3", 
		"URL=http://192.168.14.54:9433/api/ticket/countByState/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ticket_3", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("ticket_4", 
		"URL=http://192.168.14.54:9433/api/ticket/?state=-1,0,1,5&page=0&size=10", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://192.168.14.54:9433/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_end_transaction("UC01_T01_createincident",LR_AUTO);

	return 0;
}
